import json
import boto3
import os
import sys
import logging


# make sure we are running with python 3
if sys.version_info < (3, 0):
    print("Sorry, this script requires Python 3 to run")
    sys.exit(1)


# setup logging function
def setup_logging():
    """
        Logging Function.

        Creates a global log object and sets its level.
        """
    global log
    log = logging.getLogger()
    log_levels = {'INFO': 20, 'WARNING': 30, 'ERROR': 40}

    if 'logging_level' in os.environ:
        log_level = os.environ['logging_level'].upper()
        if log_level in log_levels:
            log.setLevel(log_levels[log_level])
        else:
            log.setLevel(log_levels['ERROR'])
            log.error("The logging_level environment variable is not set to INFO, WARNING, or \
                    ERROR.  The log level is set to ERROR")
    else:
        log.setLevel(log_levels['ERROR'])
        log.warning('The logging_level environment variable is not set. The log level is set to \
                    ERROR')
        log.info('Logging setup complete - set to \
            log level ' + str(log.getEffectiveLevel()))

setup_logging()


def delete_rules():
    # Create an EC2 client
    ec2 = boto3.client('ec2')
    
    # Get the default security group ID
    response = ec2.describe_security_groups(
        Filters=[{'Name': 'group-name', 'Values': ['default']}]
    )
    security_group_id = response['SecurityGroups'][0]['GroupId']
    
    #test
    print(security_group_id)
    
    # Get the existing ingress rules for the default security group
    response = ec2.describe_security_group_rules(
        Filters=[{'Name': 'group-id', 'Values': [security_group_id]}]
    )
    ingress_rules = response['SecurityGroupRules']
    
    #test
    print (ingress_rules)
    
    # Revoke each ingress rule
    for rule in ingress_rules:
        ec2.revoke_security_group_ingress(
            GroupId=security_group_id,
            CidrIp=rule['CidrIpv4'],
            IpProtocol=rule['IpProtocol'],
            FromPort=rule['FromPort'],
            ToPort=rule['ToPort']
        )
    
    print('Ingress rules deleted successfully')
    
def delete_rules2():
    client = boto3.client('ec2')
    
    vpc_id = os.environ['vpc_id']
    
    response = client.describe_security_groups(Filters=[
        {'Name': 'vpc-id', 'Values': [vpc_id]}
    ])
    # Trova il security group predefinito nel risultato della chiamata API
    for security_group in response['SecurityGroups']:
        if security_group['GroupName'] == 'default':
            # Elimina tutte le regole in ingresso
            for ingress_permission in security_group['IpPermissions']:
                client.revoke_security_group_ingress(
                    GroupId=security_group['GroupId'],
                    IpPermissions=[ingress_permission]
                )
            # Elimina tutte le regole in uscita
            for egress_permission in security_group['IpPermissionsEgress']:
                client.revoke_security_group_egress(
                    GroupId=security_group['GroupId'],
                    IpPermissions=[egress_permission]
                )
            print(f"Regole di ingresso ed uscita del Security Group predefinito {security_group['GroupId']} eliminate con successo.")
            return security_group['GroupId']
    # Se non viene trovato un security group predefinito, puoi gestire questo caso di conseguenza
    print(f"Security group predefinito non trovato per il VPC {vpc_id}")
    return None

def lambda_handler(event, context):
    # TODO implement
    
    delete_rules2()
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
