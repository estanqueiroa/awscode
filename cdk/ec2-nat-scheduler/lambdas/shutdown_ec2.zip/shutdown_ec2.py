"""
AWS Disclaimer.

(c) 2023 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
This AWS Content is provided subject to the terms of the AWS Customer
Agreement available at https://aws.amazon.com/agreement/ or other written
agreement between Customer and Amazon Web Services, Inc.

"""

import boto3
import datetime
import os
from botocore.exceptions import ClientError

def lambda_handler(event, context):

    # get aws region
    region = context.invoked_function_arn.split(":")[3]

    # start boto client
    ec2 = boto3.client('ec2', region_name=region)

    # get tag key from OS variables
    instances = os.environ['INSTANCE_ID']

    # Get the current date and time
    current_datetime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    try:

        # Add a tag to the EC2 instance with the current date and time
        ec2.create_tags(Resources=[instances], Tags=[{'Key': 'LastStopDateTime', 'Value': current_datetime}])

        # Stop EC2 NAT instance
        response = ec2.stop_instances(InstanceIds=[instances])
        print('stopped your instances: ' + str(instances))

        return response
    
    except ClientError as err:
        err.response['Error']['Code'], err.response['Error']['Message']
        raise
